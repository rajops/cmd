echo "i will update host file with IP at startup of script"
